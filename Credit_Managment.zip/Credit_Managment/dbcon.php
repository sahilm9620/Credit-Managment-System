<?php

$connection = mysqli_connect('fdb26.awardspace.net','3439586_credit','connectingthedots1','3439586_credit');

if($connection)
{
    //echo "We are connected";
}
else
{
    die("Databse connection failed");
}

?>